#!/bin/sh
gnome-terminal -e "gradle runserver0"
sleep 1
gnome-terminal -e "gradle runserver1"
sleep 1
gnome-terminal -e "gradle runserver2"
