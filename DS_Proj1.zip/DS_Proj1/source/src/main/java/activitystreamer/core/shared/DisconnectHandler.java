package activitystreamer.core.shared;

public interface DisconnectHandler {
    void closeConnection(Connection connection);
}
