package activitystreamer.client.commandhandlers;

import org.junit.Test;

import static org.mockito.Mockito.*;

public class LoginFailedCommandHandlerTest {
}
