package activitystreamer.server.services;

import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class ConcreteUserAuthServiceTest {
    @Test
    public void testRegister() {

    }
}
