The project uses Gradle to build.

Once Gradle is installed the following command:

gradle run_test

Will open some test client/servers according to the bash script in scripts/test.sh
Note that Gradle automatically resolves dependencies
